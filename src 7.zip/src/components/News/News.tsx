export const News = () => {
    return (
        <div>
            News Page
        </div>
    )
}