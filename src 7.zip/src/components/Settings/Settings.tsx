export const Settings = () => {
    return (
        <div>
            Settings Page
        </div>
    )
}