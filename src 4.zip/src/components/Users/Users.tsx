import React from "react";
import {usersPropsType} from "./UsersContainer";
import style from "./Users.module.css";
import axios from "axios";
import userPhoto from "../../assets/img/userdefault.png"

class Users extends React.Component<usersPropsType, any> {
    componentDidMount() {
        axios.get("https://social-network.samuraijs.com/api/1.0/users")
            .then(response => {
                this.props.setUser(response.data.items)
            })
    }

    render = () => {
        return (
            <div className={style.userWrap}>
                {
                    this.props.users.map(u => <div key={u.id} className={style.userItem}>
                            <div className={style.userLeft}>
                                <img src={u.photos.small != null ? u.photos.small : userPhoto} alt={u.name} width='100'/>
                                {u.followed
                                    ? <button onClick={() => {
                                        this.props.unfollow(u.id)
                                    }}>unfollow</button>
                                    : <button onClick={() => {
                                        this.props.follow(u.id)
                                    }}>follow</button>
                                }
                            </div>
                            <div className={style.userRight}>
                                <div>
                                    <p className={style.userName}>{u.name}</p>
                                    <p className={style.userStatus}>{u.status}</p>
                                </div>
                                <div>
                                    <p className={style.userCountry}>{"u.location.country"}</p>
                                    <p className={style.userCity}>{"u.location.city"}</p>
                                </div>
                            </div>
                        </div>
                    )
                }
            </div>
        )
    }
}

export default Users;