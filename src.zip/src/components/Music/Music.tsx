export const Music = () => {
    return (
        <div>
            Music Page
        </div>
    )
}