import React from "react";
import s from "./ProfileInfo.module.css";

export const ProfileInfo = () => {
    return (
        <div>
            <div className={s.mainimg}>
                <img src={''}/>
            </div>
            <div className={s.profile}>
                ava+description
            </div>

        </div>
    )
}