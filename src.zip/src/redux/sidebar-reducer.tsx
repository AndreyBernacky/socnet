import {ActionType, SidebarType} from "./store";

const sidebarReducer = (state:SidebarType, action:ActionType) => {

    return state
}

export default sidebarReducer