import React from "react";
import {Header} from "./Header";
import axios from "axios";
import {connect} from "react-redux";
import {AppStateType} from "../../redux/redux-store";
import {setAuthUserData} from "../../redux/auth-reducer";

export type mapStatePropsType = {
    id: number,
    email: string,
    login: string,
    isAuth: boolean
}
export type mapDispatchPropsType = {
    setAuthUserData: (id: number, email: string, login: string) => void
}

export type authPropsType = mapStatePropsType & mapDispatchPropsType

class HeaderWrapper extends React.Component<authPropsType, any> {
    componentDidMount() {
        axios.get('https://social-network.samuraijs.com/api/1.0/auth/me', {
            withCredentials: true
        })
            .then(response => {
                if(response.data.resultCode === 0) {
                    let {id, email, login} = response.data.data
                    this.props.setAuthUserData(id, email, login)
                }
            })
    }

    render = () => {
        return <>
            <Header
                login={this.props.login}
                isAuth={this.props.isAuth}
            />
        </>
    }
}

let mapStateToProps = (state: AppStateType) => {
    return {
        id:state.authUser.id,
        email:state.authUser.email,
        login:state.authUser.login,
        isAuth: state.authUser.isAuth
    }
}

export const HeaderContainer = connect(mapStateToProps, {setAuthUserData})(HeaderWrapper)