import React from "react";
import loading from "../../../assets/img/loading.gif";

export const Preloader = () => {
    return (
        <div>
            <img src={loading} />
        </div>
    )
}